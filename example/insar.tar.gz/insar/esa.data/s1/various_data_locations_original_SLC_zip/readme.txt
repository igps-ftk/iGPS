where you store the original Sentinel-1 SLC zip files
may in different locations
