links to all Sentinel-1 SLC files
no need to know the track number for certain tasks
